# UTFRAnnoMate
Automating 2D cone labelling with YOLOv8, Python, and a custom labeling UI to boost annotation speed compared to manual labelling, streamlining perception training for autonomous driving. 
